# PRAKTIKUM 7.2 - GRAY LEVEL SLICING

# Import library
import cv2
import numpy as np
from skimage import data
import matplotlib.pyplot as plt

#=================================
# GRAY SCALE LEVEL SLICE

# Membaca gambar ironmen2 dari directory
img = cv2.imread("ironmen2.jpg")
img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Mendapatkan ukuran baris dan kolom dari gambar
row, column = img.shape
# Membuat array kosong dengan ukuran yang sama dengan gambar
img1 = np.zeros((row, column), dtype='uint8')
# Merepresentasikan rentang nilai minimum dan maksimum
min_range = 10
max_range = 60
# Melakukan iterasi pada setiap piksel dalam gambar
for i in range(row):
    for j in range(column):
        # Jika nilai piksel berada dalam rentang yang ditentukan
        if img[i, j] > min_range and img[i, j] < max_range:
            # Set nilai piksel pada gambar hasil menjadi 255 (putih)
            img1[i, j] = 255
        else:
            # Set nilai piksel pada gambar hasil menjadi 0 (hitam)
            img1[i, j] = 0

# Membuat gambar dengan 2 baris dan 2 kolom subplot, ukuran gambar 12x12
fig, axes = plt.subplots(2, 2, figsize=(12, 12))
# Meratakan array subplot menjadi satu dimensi
ax = axes.ravel()

# Menampilkan citra input pada subplot pertama
ax[0].imshow(img, cmap=plt.cm.gray)
ax[0].set_title("Citra Input")  # Memberikan judul pada subplot pertama
# Menampilkan histogram citra input pada subplot kedua
ax[1].hist(img.ravel(), bins=256)
ax[1].set_title('Histogram Input')  # Memberikan judul pada subplot kedua

# Menampilkan citra output pada subplot ketiga
ax[2].imshow(img1, cmap=plt.cm.gray)
ax[2].set_title("Citra Output")  # Memberikan judul pada subplot ketiga
# Menampilkan histogram citra output pada subplot keempat
ax[3].hist(img1.ravel(), bins=256)
ax[3].set_title('Histogram Output')  # Memberikan judul pada subplot keempat

#Mengatur tata letak subplot agar tidak tumpang tindih
fig.tight_layout()
#Menampilkan gambar secara keseluruhan
plt.show()