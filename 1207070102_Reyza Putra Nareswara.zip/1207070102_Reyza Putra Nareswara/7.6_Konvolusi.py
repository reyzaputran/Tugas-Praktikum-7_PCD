# 7.6 - KONVOLUSI

# Import library
import matplotlib.pyplot as plt

from skimage import data
from skimage.io import imread
from skimage.color import rgb2gray 
import numpy as np

import cv2

# Membaca file gambar groot.jpg dari directory
citra1 = imread(fname="groot.jpg")
print(citra1.shape) # Menampilkan resolusi citra
# Menampilkan citra asli
plt.imshow(citra1)
plt.show()

#===================================
#PROSES KONVOLUSI

# Definisikan kernel untuk operasi filter
kernel = np.array([[-1, 0, -1], 
                   [0, 4, 0], 
                   [-1, 0, -1]])

# Terapkan operasi filter2D pada citra1 menggunakan kernel yang telah didefinisikan
citraOutput = cv2.filter2D(citra1, -1, kernel)

# Membuat subplot dengan ukuran 1x2 dan ukuran total figur 12x12
fig, axes = plt.subplots(1, 2, figsize=(12, 12))
# Meratakan array dari subplot menjadi array satu dimensi
ax = axes.ravel()

# Menampilkan citra input dalam subplot pertama
ax[0].imshow(citra1)
ax[0].set_title("Citra Input")
# Menampilkan citra output setelah operasi filter dalam subplot kedua
ax[1].imshow(citraOutput)
ax[1].set_title("Citra Output")

# Mengatur posisi gambar agar tidak tumpang tindih
fig.tight_layout()
# Menampilkan semua subplot
plt.show()


