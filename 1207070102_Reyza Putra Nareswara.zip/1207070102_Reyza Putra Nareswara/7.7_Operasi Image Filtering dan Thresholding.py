# 7.7 (1) - OPERASI IMAGE FILTERING DAN THRESHOLDING

#Import library
import cv2
import numpy as np
from matplotlib import pyplot as plt

#=====================================
# IMAGE FILTERING

#=====================================
# Melakukan Operasi Image Filtering dengan OpenCV

# 1. Low-Pass Filtering

# Membaca file groot.jpg dari directory
img = cv2.imread('groot.jpg')
# Mengubah susunan citra dari BGR ke RGB
groot = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
# Menampilkan gambar/citra asli
cv2.imshow("Original",img)

# Membuat filter: matriks berukuran 5 x 5 
kernel = np.ones((5,5),np.float32)/25
print(kernel)
# Melakukan proses filter
groot_filter = cv2.filter2D(img,-1,kernel)
# Menampilkan gambar hasil filter
cv2.imshow("Hasil Filter",groot_filter)
plt.hist(groot_filter.ravel(), bins=256, color="blue", alpha=0.5),
plt.title("Histogram Hasil Filter")
plt.xticks([]), plt.yticks([])
plt.show()

# Memperbesar ukuran hasil plotting jika diperlukan
plt.rcParams["figure.figsize"] = (15,15)

# Subplot pertama, gambar asli
plt.subplot(221),plt.imshow(groot),
# Memberi judul pada gambar yang ditampilkan pada subplot pertama
plt.title('Original')
# Mengatur label sumbu x dan y agar tidak berlabel
plt.xticks([]), plt.yticks([])

# Subplot kedua, hasil filter
plt.subplot(222),plt.imshow(groot_filter),
# Memberi judul pada gamabr yang ditampilkan pada subplot kedua
plt.title('Averaging')
# Mengatur label sumbu x dan y agar tidak berlabel
plt.xticks([]), plt.yticks([])

# Subplot ketiga, histogram gambar asli
plt.subplot(223),
# Menampilkan histogram dari citra original
plt.hist(groot.ravel(), bins=256, color="red", alpha=0.5),
# Memberi judul histogram yang ditampilkan
plt.title("Histogram Gambar Original")
# Mengatur label sumbu x dan y agar tidak berlabel
plt.xticks([]), plt.yticks([])

# Subplot keempat, histogram gambar hasil filter
plt.subplot(224),
# Menampilkan histogram dari citra yang sudah difilter
plt.hist(groot_filter.ravel(), bins=256, color="blue", alpha=0.5),
# Memberi judul histogram yang ditampilkan
plt.title("Histogram Hasil Filter")
# Mengatur label sumbu x dan y agar tidak berlabel
plt.xticks([]), plt.yticks([])

# Menampilkan gambar
plt.show()

 #==============================================
# Membuat gambar menjadi blur menggunakan fungsi
groot_blur = cv2.blur(img,(4,4))

# Menampilkan gambar hasil blur
cv2.imshow("Hasil Blur",groot_blur)

# Menampilkan histogram hasil filter citra (blur)
fig, axes = plt.subplots(1, 1, figsize=(4, 4))
plt.hist(groot_blur.ravel(), bins=256, color="green", alpha=0.5),
# Memberi judul histogram yang ditampilkan
plt.title("Histogram Hasil Filter (Blur)")
# Mengatur label sumbu x dan y agar tidak berlabel
plt.xticks([]), plt.yticks([])

# Menampilkan gambar secara keseluruhan
plt.show()

# Terdapat cara lain untuk membuat sebuah kernel, 
# yaitu dengan menggunakan np.matrix
# kali ini, ukuran matriksnya 3 x 3
kernel = np.matrix([
          [1, 1, 1],
          [1, 2, 1],
          [1, 1, 1]         
          ])/25
print(kernel)

# Melakukan filtering kembali
groot_filter = cv2.filter2D(img,-1,kernel)

# Menampilkan gambar hasil filtering
cv2.imshow("Hasil Filter",groot_filter)

# Menampilkan histogram hasil filter citra setelah kernel diubah
fig, axes = plt.subplots(1, 1, figsize=(4, 4))
plt.hist(groot_blur.ravel(), bins=256, color="green", alpha=0.5),
# Memberi judul histogram yang ditampilkan
plt.title("Histogram Hasil Filter (Kernel diubah)")
# Mengatur label sumbu x dan y agar tidak berlabel
plt.xticks([]), plt.yticks([])

# Menampilkan gambar secara keseluruhan
plt.show()


#==============================================
# HIGH-PASS FILTERING

# Memanggil citra sebagai grayscale (argument 0)
img = cv2.imread('capt_america.jpg',0)

# Menerapkan algoritma high-pass filtering: laplacian
laplacian = cv2.Laplacian(img,cv2.CV_64F)

# Sobel dengan ukuran kernel 5 (Deteksi garis tepi)
sobelx = cv2.Sobel(img,cv2.CV_64F,1,0,ksize=5)
sobely = cv2.Sobel(img,cv2.CV_64F,0,1,ksize=5)

# Catatan:
# CV_64F pada contoh di atas menunjukkan nilai bit dari citra 
# yang dihasilkan serta tipe datanya (F = Float)

# Memperbesar ukuran hasil plotting 
plt.rcParams["figure.figsize"] = (20,20)

# Menampilkan hasil filter

# Menampilkan gambar original
plt.subplot(2,4,1),plt.imshow(img,cmap = 'gray')
plt.title('Original'), plt.xticks([]), plt.yticks([])
# Menampilkan gambar hasil filter dengan metode Laplacian
plt.subplot(2,4,2),plt.imshow(laplacian,cmap = 'gray')
plt.title('Laplacian'), plt.xticks([]), plt.yticks([])
# Menampilkan gambar hasil edge detection horizontal
plt.subplot(2,4,3),plt.imshow(sobelx,cmap = 'gray')
plt.title('Sobel X'), plt.xticks([]), plt.yticks([])
# Menampilkan gambar hasil edge detection vertical
plt.subplot(2,4,4),plt.imshow(sobely,cmap = 'gray')
plt.title('Sobel Y'), plt.xticks([]), plt.yticks([])

# Menampilkan histogram hasil filter citra setelah kernel diubah
plt.subplot(2,4,5)
plt.hist(img.ravel(), bins=256, color="red", alpha=0.5),
# Memberi judul histogram yang ditampilkan
plt.title("Histogram Gambar Original")
# Mengatur label sumbu x dan y agar tidak berlabel
plt.xticks([]), plt.yticks([])

# Menampilkan histogram hasil filter laplacian
plt.subplot(2,4,6)
plt.hist(laplacian.ravel(), bins=256, color="green", alpha=0.5),
# Memberi judul histogram yang ditampilkan
plt.title("Histogram  Laplacian")
# Mengatur label sumbu x dan y agar tidak berlabel
plt.xticks([]), plt.yticks([])

# Menampilkan histogram hasil filter edge detection horizontal
plt.subplot(2,4,7)
plt.hist(sobelx.ravel(), bins=256, color="blue", alpha=0.5),
# Memberi judul histogram yang ditampilkan
plt.title("Histogram ED-Horizontal")
# Mengatur label sumbu x dan y agar tidak berlabel
plt.xticks([]), plt.yticks([])

# Menampilkan histogram hasil filter citra setelah kernel diubah
plt.subplot(2,4,8)
plt.hist(sobely.ravel(), bins=256, color="black", alpha=0.5),
# Memberi judul histogram yang ditampilkan
plt.title("Histogram ED-Vertical")
# Mengatur label sumbu x dan y agar tidak berlabel
plt.xticks([]), plt.yticks([])
plt.show()

# Memanggil citra sebagai grayscale (argument 0)
img = cv2.imread('ironmen2.jpg',0)

# Memanggil fungsi Canny Edges dengan argument (citra, nilai_min, nilai_max)
edges = cv2.Canny(img,100,200)

# Menampilkan gambar asli dan gambar setelah dioperasikan fungsi canny
plt.subplot(221),plt.imshow(img,cmap = 'gray')
plt.title('Original Image'), plt.xticks([]), plt.yticks([])
plt.subplot(222),plt.imshow(edges,cmap = 'gray')
plt.title('Edge Image'), plt.xticks([]), plt.yticks([])
# Menampilkan histogram dari gambar asli dan gambar setelah dioperasikan fungsi canny
plt.subplot(223),plt.hist(img.ravel(), bins=256, color="blue", alpha=0.5),
# Memberi judul histogram yang ditampilkan
plt.title("Histogram Original")
# Mengatur label sumbu x dan y agar tidak berlabel
plt.xticks([]), plt.yticks([])

plt.subplot(224),plt.hist(edges.ravel(), bins=256, color="green", alpha=0.5),
# Memberi judul histogram yang ditampilkan
plt.title("Histogram Edge(Canny)")
# Mengatur label sumbu x dan y agar tidak berlabel
plt.xticks([]), plt.yticks([])
# Menampilkan gambar 
plt.show()

#===================================
# IMAGE THRESHOLDING

# Membaca gambar groot
img1 = cv2.imread('groot.jpg',0)

# Hitungan threshold.
# Perhatikan nilai ambang batas bawah dan atas dari tiap fungsi yang diberikan
ret,thresh1 = cv2.threshold(img1,127,255,cv2.THRESH_BINARY) # Threshold biner
ret,thresh2 = cv2.threshold(img1,127,255,cv2.THRESH_BINARY_INV) # Threshold biner terbalik(inverted)
ret,thresh3 = cv2.threshold(img1,127,255,cv2.THRESH_TRUNC) # Threshold truncate
ret,thresh4 = cv2.threshold(img1,127,255,cv2.THRESH_TOZERO) # Threshold to zero
ret,thresh5 = cv2.threshold(img1,127,255,cv2.THRESH_TOZERO_INV) # Threshold to zero terbalik(inverted)

# Menampilkan hasil threshold
titles = ['Gambar asli','BINARY','BINARY_INV','TRUNC','TOZERO','TOZERO_INV']
images = [img1, thresh1, thresh2, thresh3, thresh4, thresh5]

# Menampilkan beberapa gambar sekaligus
for i in range(6):
    # 3 baris, 2 kolom
    plt.subplot(3,2,i+1),plt.imshow(images[i],'gray')
    plt.title(titles[i])
    plt.xticks([]),plt.yticks([])
# Menampilkan gambar 
plt.show()

# Menampilkan histogram hasil threshold
titles = ['Hist Gambar asli','Hist BINARY','Hist BINARY_INV','Hist TRUNC','Hist TOZERO','Hist TOZERO_INV']
images = [img1, thresh1, thresh2, thresh3, thresh4, thresh5]

# Menampilkan beberapa gambar sekaligus
for i in range(6):
    # 3 baris, 2 kolom
    plt.subplot(3,2,i+1),plt.hist(images[i].ravel(),bins=256)
    plt.title(titles[i])
    plt.xticks([]),plt.yticks([])
    # Menampilkan gambar
plt.show()
#===========================================
# Masih menggunakan variabel img1 yang sama di atas 
# (img1 = cv2.imread('images/groot.jpg',0))

# Digunakan median blur untuk menghaluskan tepi objek pada citra
# Ini diperlukan agar thresholding memberikan hasil lebih baik
img1 = cv2.medianBlur(img1,5)

# Melakukan Thresholding
# Binary Threshold
ret,th1 = cv2.threshold(img1,127,255,cv2.THRESH_BINARY)

# Adaptive Threshold dengan Mean
th2 = cv2.adaptiveThreshold(img1,255,cv2.ADAPTIVE_THRESH_MEAN_C,\
            cv2.THRESH_BINARY,11,2)

# Adaptive Threshold dengan Gaussian
th3 = cv2.adaptiveThreshold(img1,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,\
            cv2.THRESH_BINARY,11,2)


# Plotting untuk menampilkan hasil thresholding
titles = ['Original Image', 'Global Thresholding (v = 127)',
            'Adaptive Mean Thresholding', 'Adaptive Gaussian Thresholding']
images = [img1, th1, th2, th3]

# Menampilkan beberapa hasil sekaligus
for i in range(4):
    plt.subplot(2,2,i+1)
    plt.imshow(images[i],'gray')
    plt.title(titles[i])
    plt.xticks([]),plt.yticks([])
# Menampilkan gambar secara keseluruhan
plt.show()

# Plotting untuk menampilkan Histogram hasil thresholding
titles = ['Hist Original Image', 'Hist Global Thresholding (v = 127)',
            'Hist Adaptive Mean Thresholding', 'Hist Adaptive Gaussian Thresholding']
images = [img1, th1, th2, th3]

# Menampilkan beberapa hasil sekaligus
for i in range(4):
    plt.subplot(2,2,i+1)
    plt.hist(images[i].ravel(),bins=256,color='red',alpha=0.5)
    plt.title(titles[i])
    plt.xticks([]),plt.yticks([])
# Menampilkan gambar secara keseluruhan
plt.show()