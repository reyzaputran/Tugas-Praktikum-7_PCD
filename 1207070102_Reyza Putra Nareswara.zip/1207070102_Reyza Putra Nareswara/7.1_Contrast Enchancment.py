# Praktikum 7.1 - Contrast Enchancment

#Import library
import numpy as np
import matplotlib.pyplot as plt
import cv2
import matplotlib.image as mpimg

#Membuat variabel image untuk membaca gambar camera dari skimage
image = cv2.imread("ironmen2.jpg") 
image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

#========================================
#PENERAPAN METODE HISTOGRAM EQUALIZATION

#Membuat variabel untuk menerapkan histogram equalization menggunakan fungsi
image_equalized = cv2.equalizeHist(image)

#========================================
#PENERAPAN METODE CLAHE

#Membuat variabel untuk menerapkan metode CLAHE menggunakan fungsi
clahe = cv2.createCLAHE(clipLimit=2, tileGridSize=(8,8))

#Metode CLAHE diterapkan pada gambar asli
image_clahe = clahe.apply(image)

#========================================
#PENERAPAN METODE CONTRAST STRETCHING (CS)

#Membuat array kosong sebagai wadah output
image_cs = np.zeros((image.shape[0],image.shape[1]),dtype = 'uint8')
#Mendeklarasikan min-max contrast
#Menghitung nilai minimum dan maksimum dalam array gambar
min = np.min(image)
max = np.max(image)
#Melakukan iterasi pada setiap piksel dalam gambar
for i in range(image.shape[0]):
    for j in range(image.shape[1]):
        #Melakukan penskalaan nilai piksel ke rentang [0, 255]
        image_cs[i, j] = 255 * (image[i, j] - min) / (max - min)

#=======================================
#PENERAPAN METODE PERKALIAN KONSTANTA

#Membuat salinan array gambar dan mengubah tipe datanya menjadi float
ironmancopy = image.copy().astype(float)

#Mendapatkan ukuran baris dan kolom dari array gambar yang disalin
m1, n1 = ironmancopy.shape
#Membuat array kosong dengan ukuran yang sama dengan array gambar
output1 = np.empty([m1, n1])

#Melakukan iterasi pada setiap piksel dalam gambar
for baris in range(0, m1-1):
    for kolom in range(0, n1-1):
        #Mengalikan nilai piksel dengan faktor 1.9
        a1 = baris
        b1 = kolom
        output1[a1, b1] = ironmancopy[baris, kolom] * 1.9

#Membuat subplot dengan ukuran 5 baris dan 2 kolom, serta ukuran gambar keseluruhan 20x20
fig, axes = plt.subplots(5, 2, figsize=(20, 20))
ax = axes.ravel()

#Menampilkan citra input pada subplot 0
ax[0].imshow(image, cmap=plt.cm.gray)
ax[0].set_title("Citra Input")
#Menampilkan histogram citra input pada subplot 1
ax[1].hist(image.ravel(), bins=256)
ax[1].set_title('Histogram Input')

#Menampilkan citra output hasil histogram equalization pada subplot 2
ax[2].imshow(image_equalized, cmap=plt.cm.gray)
ax[2].set_title("Citra Output HE")
#Menampilkan histogram citra output hasil histogram equalization pada subplot 3
ax[3].hist(image_equalized.ravel(), bins=256)
ax[3].set_title('Histogram Output HE Method')

#Menampilkan citra output hasil contrast stretching pada subplot 4
ax[4].imshow(image_cs, cmap=plt.cm.gray)
ax[4].set_title("Citra Output CS")
#Menampilkan histogram citra output hasil contrast stretching pada subplot 5
ax[5].hist(image_cs.ravel(), bins=256)
ax[5].set_title('Histogram Output CS Method')

#Menampilkan citra output hasil CLAHE (Contrast Limited Adaptive Histogram Equalization) pada subplot 6
ax[6].imshow(image_clahe, cmap=plt.cm.gray)
ax[6].set_title("Citra Grayscale CLAHE")
#Menampilkan histogram citra output hasil CLAHE pada subplot 7
ax[7].hist(image_clahe.ravel(), bins=256)
ax[7].set_title('Histogram Output CLAHE Method')

#Menampilkan citra output hasil perkalian konstanta pada subplot 8
ax[8].imshow(output1, cmap=plt.cm.gray)
ax[8].set_title("Citra Grayscale Perkalian Konstanta")
#Menampilkan histogram citra output hasil perkalian konstanta pada subplot 9
ax[9].hist(output1.ravel(), bins=256)
ax[9].set_title('Histogram Output Perkalian Konstanta Method')

#Mengatur tata letak subplot agar tidak tumpang tindih
fig.tight_layout()
#Menampilkan gambar secara keseluruhan
plt.show()

