# 7.3 - FILTER RERATA

# Import library
import matplotlib.pyplot as plt
from skimage import data
from skimage.io import imread
from skimage.color import rgb2gray 
import numpy as np
import cv2

# Memuat citra 1 dari file "ironmen2.jpg" menggunakan imread
citra1 = imread(fname="ironmen2.jpg")
citra1 = cv2.cvtColor(citra1, cv2.COLOR_BGR2GRAY)
# Memuat citra 2 dari file "groot.jpg" menggunakan imread
citra2 = imread(fname="groot.jpg")
citra2= cv2.cvtColor(citra2, cv2.COLOR_BGR2GRAY)

# Menampilkan dimensi citra 1
print('Shape citra 1: ', citra1.shape)
# Menampilkan dimensi citra 2
print('Shape citra 2: ', citra2.shape)

# Membuat gambar dengan 1 baris dan 2 kolom subplot, ukuran gambar 10x10
fig, axes = plt.subplots(1, 2, figsize=(10, 10))
# Meratakan array subplot menjadi satu dimensi
ax = axes.ravel()

# Menampilkan citra 1 pada subplot pertama
ax[0].imshow(citra1, cmap='gray')
ax[0].set_title("Citra 1")  # Memberikan judul pada subplot pertama
# Menampilkan citra 2 pada subplot kedua
ax[1].imshow(citra2, cmap='gray')
ax[1].set_title("Citra 2")  # Memberikan judul pada subplot kedua

# Mengatur posisi gambar agar tidak tumpang tindih
fig.tight_layout()
# Menampilkan gambar
plt.show()

# MENYIAPKAN VARIABEL OUTPUT

# Membuat salinan citra 1 dan mengonversinya menjadi tipe float
copyCitra1 = citra1.copy().astype(float)
# Membuat salinan citra 2 dan mengonversinya menjadi tipe float
copyCitra2 = citra2.copy().astype(float)

# Mendapatkan dimensi citra 1
m1, n1 = copyCitra1.shape
# Membuat array kosong dengan ukuran yang sama dengan citra 1
output1 = np.empty([m1, n1])

# Mendapatkan dimensi citra 2
m2, n2 = copyCitra2.shape
# Membuat array kosong dengan ukuran yang sama dengan citra 2
output2 = np.empty([m2, n2])

# Menampilkan dimensi citra 1 dan output 1
print('Shape copy citra 1: ', copyCitra1.shape)
print('Shape output citra 1: ', output1.shape)
# Menampilkan nilai m1 dan n1
print('m1: ', m1)
print('n1: ', n1)
print()

# Menampilkan dimensi citra 2 dan output 2
print('Shape copy citra 2: ', copyCitra2.shape)
print('Shape output citra 2: ', output2.shape)
# Menampilkan nilai m2 dan n2
print('m2: ', m2)
print('n2: ', n2)
print()

#=======================================
#PROSES FILTER RERATA PADA CITRA INPUT 1

# Melakukan iterasi pada setiap baris dalam citra 1
for baris in range(0, m1-1):
    # Melakukan iterasi pada setiap kolom dalam citra 1
    for kolom in range(0, n1-1):
        # Menyimpan indeks baris dan kolom saat ini
        a1 = baris
        b1 = kolom
        # Menghitung jumlah dari 9 piksel sekitar (3x3) pada citra 1
        jumlah = copyCitra1[a1-1, b1-1] + copyCitra1[a1-1, b1] + copyCitra1[a1-1, b1+1] + \
                 copyCitra1[a1, b1-1] + copyCitra1[a1, b1] + copyCitra1[a1, b1+1] + \
                 copyCitra1[a1+1, b1-1] + copyCitra1[a1+1, b1] + copyCitra1[a1+1, b1+1]
        # Menghitung nilai rata-rata dari piksel-piksel sekitar
        output1[a1, b1] = (1/9) * jumlah

#=======================================
#PROSES FILTER RERATA PADA CITRA INPUT 2

# Melakukan iterasi pada setiap baris dalam citra 2
for baris1 in range(0, m2-1):
    # Melakukan iterasi pada setiap kolom dalam citra 2
    for kolom1 in range(0, n2-1):
        # Menyimpan indeks baris dan kolom saat ini
        a1 = baris1
        b1 = kolom1
        
        # Menghitung jumlah dari 9 piksel sekitar (3x3) pada citra 2
        jumlah = copyCitra2[a1-1, b1-1] + copyCitra2[a1-1, b1] + copyCitra2[a1-1, b1+1] + \
                 copyCitra2[a1, b1-1] + copyCitra2[a1, b1] + copyCitra2[a1, b1+1] + \
                 copyCitra2[a1+1, b1-1] + copyCitra2[a1+1, b1] + copyCitra2[a1+1, b1+1]
        
        # Menghitung nilai rata-rata dari piksel-piksel sekitar
        output2[a1, b1] = (1/9) * jumlah

#=======================================
# PLOT CITRA INPUT DAN OUTPUT HASIL DARI FILTER RERATA

# Membuat subplots dengan ukuran 2x2
fig, axes = plt.subplots(2, 2, figsize=(10, 10))
ax = axes.ravel()

# Menampilkan citra 1 pada subplot pertama
ax[0].imshow(citra1, cmap='gray')
ax[0].set_title("Input Citra 1") # Memberi judul

# Menampilkan citra 2 pada subplot kedua
ax[1].imshow(citra2, cmap='gray')
ax[1].set_title("Input Citra 2") # Memberi judul

# Menampilkan output citra 1 pada subplot ketiga
ax[2].imshow(output1, cmap='gray')
ax[2].set_title("Output Citra 1") # Memberi judul

# Menampilkan output citra 2 pada subplot keempat
ax[3].imshow(output2, cmap='gray')
ax[3].set_title("Output Citra 2") # Memberi judul

# Mengatur posisi gambar agar tidak tumpang tindih
fig.tight_layout()
# Menampilkan gambar 
plt.show()